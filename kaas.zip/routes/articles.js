const express = require('express');
const router = express.Router();
const passport = require('passport');

// bring in article model
// bring in models
let Article = require('../models/article');
let User = require('../models/user');
let Selling = require('../models/sellings');
// Add Article route
router.get('/newsell',ensureAuthenticated, (req, res)=>{
  res.render('newsell');
});

//listings page
router.get('/Listings', (req, res) => {
  Selling.find({}, (err, Selling) =>{
    if(err){
      console.log(err);
    }
    else{
      res.render('Listings', {
        title: 'Articles',
        sellings: Selling
      });
    }
  });
});

// Acces controls
function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
    req.flash('error_msg', 'Please login to do that');
    res.redirect('/')
  }
}

// Add Article Submission
router.post('/newsell', (req, res) =>{
  req.checkBody('title','Title is required').notEmpty();
  req.checkBody('shortdesc','Short desc is required').notEmpty();
  req.checkBody('longdesc','Long desc is required').notEmpty();
  req.checkBody('price','price is required').notEmpty();
  req.checkBody('pemail','Email is required').notEmpty();
  req.checkBody('pusername','Username is required').notEmpty();
  req.checkBody('ppassword1','Password is required').notEmpty();
  req.checkBody('ppassword2','Passwords need to match').notEmpty();

  // Get errors
  let errors = req.validationErrors();
  if(errors){
    req.flash('error_msg', 'Make sure to fill in all forms!');
    res.redirect('/articles/newsell');
    errors:errors;

  } else{
    let selling = new Selling();
    selling.title = req.body.title;
    selling.author = req.user._id;
    selling.shortdesc = req.body.shortdesc;
    selling.longdesc = req.body.longdesc;
    selling.price = req.body.price;
    selling.pemail = req.body.pemail;
    selling.pusername = req.body.pusername;
    selling.ppassword = req.body.ppassword1;
    selling.username = req.user.username;

    selling.save((err) =>{
      if(err){
        req.flash('error_msg', 'There was an error submitting your selling');
        res.redirect('/');
        console.log(err);
        return;
      } else {
        console.log('User added new selling');
        req.flash('success_msg', 'Selling Added');
        res.redirect('/');
      }
    });
  }
});

// Send edited version
router.post('/edit/:id', (req, res) =>{
  let selling = {};
  selling.title = req.body.title;
  selling.shortdesc = req.body.shortdesc;
  selling.longdesc = req.body.longdesc;
  selling.price = req.body.price;

  let query = {_id:req.params.id}

  Selling.update(query, selling, (err)=>{
    if(err){
      console.log(err);
      req.flash('error_msg', 'Failed to update article');
      res.redirect('/edit/:id');
      return;
    } else{
      req.flash('success_msg', 'Article Updated');
      res.redirect('/');
      console.log('User edited article: ' + req.params.id);
    }
  })
});

// Delete
router.post('/delete/:id', (req, res) =>{
   if(!req.user._id){
     res.status(500).send();
   }

  let query = {_id:req.params.id}
  Selling.findById(req.params.id, (err, selling)=>{
    if(selling.author != req.user._id){
      res.status(500).send();
    }else{
      let article = {};
      Selling.remove(query, (err, result) =>{
        if(err){
          console.log(err);
          req.flash('error_msg', 'Failed to delete article');
          res.redirect('/');
        } else{
          req.flash('success_msg', 'Article deleted');
          res.redirect('/');
        }
      });
      console.log('Deleted article: '+ req.params.id);
    }
  });
});

//Get single article
router.get('/:id', (req, res, next) =>{
  Selling.findById(req.params.id, (err, Selling) =>{
    User.findById(Selling.author, (err, user)=>{
      let mayEdit = false;
      if(req.user == undefined) {
        console.log(mayEdit);
        res.render('view_selling',{
          title: Selling.title,
          username: Selling.username,
          shortdesc: Selling.shortdesc,
          _id: Selling._id,
          longdesc: Selling.longdesc,
          price: Selling.price,
          mayEdit: mayEdit
        });
      } else if(Selling.author == req.user._id){
        mayEdit = true;
        console.log(mayEdit);
        res.render('view_selling',{
          title: Selling.title,
          username: Selling.username,
          shortdesc: Selling.shortdesc,
          _id: Selling._id,
          longdesc: Selling.longdesc,
          price: Selling.price,
          mayEdit: mayEdit
        });
      } else {
        console.log(mayEdit);
        res.render('view_selling',{
          title: Selling.title,
          username: Selling.username,
          shortdesc: Selling.shortdesc,
          _id: Selling._id,
          longdesc: Selling.longdesc,
          price: Selling.price,
          mayEdit: mayEdit
        });
      }
    });
  });
});

// Load edit form
router.get('/edit/:id',ensureAuthenticated, (req, res) =>{
  Selling.findById(req.params.id, (err, selling) =>{
    if(selling.author != req.user._id){
      req.flash('error_msg', 'Not authorized');
      res.redirect('/');
    }else{
      res.render('edit',{
        title: selling.title,
        shortdesc: selling.shortdesc,
        _id: selling._id,
        longdesc: selling.longdesc,
        price: selling.price
      });
    }
  });
});



module.exports = router;

const express = require('express');
const router = express.Router();

//Contact page
router.get('/contact', (req, res) => {
  res.render('contact');
});

//pricing page
router.get('/pricing', (req, res) => {
  res.render('pricing');
});

//about page
router.get('/about', (req, res) => {
  res.render('about');
});

module.exports = router;

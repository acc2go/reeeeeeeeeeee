const express = require('express');
const paypal = require('paypal-rest-sdk');
const router = express.Router();
const passport = require('passport');

paypal.configure({
  'mode': 'sandbox', //sandbox or live
  'client_id': 'ATpYgcv4xfVJGWOUxZe0u9iLf71CDVhzqaqs5XneyTNHc3zLw85KEdgeT2go6KEJ9Bky0FdSaJN13HFv',
  'client_secret': 'EMCc9hfX_94zk3jXNM1zOJ_hSoyQMW1QvvRijQbDSFql9aC461mO6FvL1_iJmo_GpBdSgoXbMqYGO0-r'
});
// Acces controls
function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
    req.flash('error_msg', 'Please login to do that');
    res.redirect('/')
  }
}

let Selling = require('../models/sellings');
router.post('/pay/:id',ensureAuthenticated, (req, res) =>{
  Selling.findById(req.params.id, (err, Selling) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://localhost:6969/payment/success/" + Selling._id,
          "cancel_url": "http://localhost:6969/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": Selling.title,
                  "sku": Selling._id,
                  "price": Selling.price,
                  "currency": "USD",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "USD",
              "total": Selling.price
          },
          "description": "This is the payment description."
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

});

router.get('/success/:id', (req, res) => {
  Selling.findById(req.params.id, (err, Selling) =>{
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "USD",
          "total": Selling.price
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        //console.log("Get payment response");
      //  console.log(JSON.stringify(payment));
        let selling = {};
        selling.available = "2";
        Selling.update(selling, (err)=>{
          if(err){
            console.log(err);
            return;
          } else{
            res.render('success');
          }
        });
      }
    });
  });
});

router.post('/success/:id', (req, res) => {
  res.redirect('/articles/Listings');
});
router.get('/cancel', (req, res) => res.send('Payment cancelled'));

module.exports = router;

const mongoose = require('mongoose');

// User schema
const UserSchema = mongoose.Schema({
  name:{
    type: String,
    required: true
  },
  lower_email:{
    type: String,
    required: true
  },
  password:{
    type: String,
    required: true
  },
  igname:{
    type: String,
    required: true
  },
  country:{
    type: String,
    required: false
  },
  street:{
    type: String,
    required: false
  },
  postcode:{
    type: String,
    required: false
  },
  mobilephone:{
    type: String,
    required: false
  },
  province:{
    type: String,
    required: false
  },
  discordname:{
    type: String,
    required: false
  },
});

const User = module.exports = mongoose.model('user', UserSchema);

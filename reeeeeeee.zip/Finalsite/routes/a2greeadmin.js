const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
var flash = require('connect-flash');
const paypal = require('paypal-rest-sdk');

function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
    req.flash('error_msg', 'Please login to do that');
    res.redirect('/')
  }
}

// bring in models
let User = require('../models/user');
let Selling = require('../models/sellings');

router.get('/viewall', ensureAuthenticated, (req, res) => {
  User.find({}, (err, user) =>{
    if(err){
      console.log(err);
    }
    else{
      Selling.find({}, (err, Selling) =>{
        if(err){
          console.log(err);
        }
        else{
          res.render('viewall', {
            sellings: Selling,
            users: user
          });
        }
      });
    }
  });
});
module.exports = router;

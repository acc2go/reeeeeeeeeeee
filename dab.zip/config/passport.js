//var passport = require('passport')
const LocalStrategy = require('passport-local').Strategy;
const User = require('../models/user');
const config = require('../config/database');
const bcrypt = require('bcryptjs');
const express = require('express');
const moment = require('moment');
var flash = require('connect-flash');
var app = express();
const expressValidator = require('express-validator');

module.exports = function(passport){
  // LocalStrategy
  passport.use(new LocalStrategy(function(username, password, done){
    //match username
    let query = {username:username};
    User.findOne(query, function(err, user){
      if(err){
        console.log(err);
      }
      if(!user){
        console.log('No user found');
        return done(null, false, {message: 'No user found'});
      //  return done(null, false, {error_msg: 'No user found'});
      }
      bcrypt.compare(password, user.password, function(err, isMatch){
        if(err){
          console.log(err);
        }
        if(isMatch){
          console.log('match');
          return done(null, user);
        }else{
          console.log('wrong password');
          //res.flash('error_msg', 'Wrong password')
          return done(null, false, {message: 'Password Incorrect'});
        }
      });
    });
  }));
  passport.serializeUser(function(user, done) {
    done(null, user.id);
  });

  passport.deserializeUser(function(id, done) {
    User.findById(id, function(err, user) {
      done(err, user);
    });
  });
}

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
var flash = require('connect-flash');

// bring in user model
// bring in models
let User = require('../models/user');

// Register form
router.get('/register', (req, res) =>{
  res.render('register');
});

// Register process
router.post('/register', (req, res) =>{
  const username = req.body.username;
  const password = req.body.password;

    let newUser = new User({
      username:username,
      password:password
    });
    bcrypt.genSalt(10,(err, salt) =>{
      bcrypt.hash(newUser.password, salt, (err, hash) =>{
        if(err){
          return;
        }
        newUser.password = hash;
        newUser.save((err)=>{
          if(err){
            console.log(err);
              return;
          } else {
            res.redirect('/');
          }
        });
      });
      });
  });

router.use(flash());
router.use(passport.initialize());
router.use(passport.session());


// Logout
router.get('/logout', (req, res)=>{
  req.logout();
  req.flash('success_msg', 'You are logged out');
  res.redirect('/');
});

module.exports = router;

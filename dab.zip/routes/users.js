const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
var flash = require('connect-flash');
// =============================== //
let User = require('../models/user');
//vars / bring in models
//===========================================================================//

//===========================================================================//
router.get('/register', (req, res) =>{
  res.render('register');
});
//get register form

router.post('/register', (req, res) =>{
  const username = req.body.username;
  const password = req.body.password;

    let newUser = new User({
      username:username,
      password:password
    });
    bcrypt.genSalt(10,(err, salt) =>{
      bcrypt.hash(newUser.password, salt, (err, hash) =>{
        if(err){
          return;
        }
        newUser.password = hash;
        newUser.save((err)=>{
          if(err){
            console.log(err);
              return;
          } else {
            res.redirect('/options');
          }
        });
      });
      });
  });
// register post route.
//===========================================================================//

//===========================================================================//
router.use(flash());
router.use(passport.initialize());
router.use(passport.session());
//router use for login purposes.
//===========================================================================//

module.exports = router;

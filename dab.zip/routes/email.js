const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');
//         end of vars.
router.get('/send', (req, res)=>{
  res.render('email');
});
router.post('/sent', (req, res)=>{
  nodemailer.createTestAccount((err, account) => {
    let transporter = nodemailer.createTransport({
      host: 'smtp-relay.sendinblue.com',
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        	user: "suppfiberise@gmail.com",
          pass: "j2GwXFa1xkIJYT8E"
              //USED SENDINBLUE.COM
      }
    });
    let mailOptions = {
      from: req.body.field1, // sender address
      to: req.body.field2, // list of receivers
      subject: req.body.field3, // Subject line
      text: req.body.field4// plain text body
    };
      // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
    });
  });
  res.render('email');
});
//             end of X
module.exports = router;

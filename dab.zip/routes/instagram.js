const express = require('express');
const followers = require('instagram-followers');
const router = express.Router();
var followercount = 0;
var usernameinsta = undefined;
//Variables.
//===========================================================================//

//===========================================================================//
router.get('/all', (req, res)=>{
  res.render('instagram',{
    followercount: followercount,
    usernameinsta: usernameinsta
  });
});
//Get instagram page.

router.post('/upload', (req, res)=>{
  followers(req.body.username).then(no => {
      followercount = no;
      usernameinsta = req.body.username;
      res.redirect('/instagram/all');
  });
});
//Post command for instagram username(followers.)
//===========================================================================//

module.exports = router;

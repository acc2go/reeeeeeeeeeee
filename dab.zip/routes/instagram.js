const express = require('express');
const followers = require('instagram-followers');
const router = express.Router();
var followercount = 0;
var usernameinsta = undefined;
//         end of vars.

router.get('/all', (req, res)=>{
  res.render('instagram',{
    followercount: followercount,
    usernameinsta: usernameinsta
  });
});

router.post('/upload', (req, res)=>{
  followers(req.body.username).then(no => {
      followercount = no;
      usernameinsta = req.body.username;
      res.redirect('/instagram/all');
  });
});

//             end of X
module.exports = router;

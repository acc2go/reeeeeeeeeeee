// Declare variables
const path = require('path');
const moment = require('moment');
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const exphbs = require('express-handlebars');
const expressValidator = require('express-validator');
const flash = require('connect-flash');
const handlebars = require('handlebars');
var formidable = require('formidable');
var fs = require('fs');
const followers = require('instagram-followers');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('./config/database');
const passport = require('passport');
// Init app
const app = express();
const port = 80;
//                 ends of variables
mongoose.connect(config.database);
let db = mongoose.connection;

// Check connection
db.once('open', () =>{
  console.log('Connected to MongoDB');
});

// Check for DB errors
db.on('error', (err) =>{
  console.log(err);
});

// bring in models
let Article = require('./models/article');
let User = require('./models/user');
let Selling = require('./models/sellings');

//            ends of mongo
// Express Session Middleware
app.use(session({
  secret: 'keyboard cat',
  resave: true,
  saveUninitialized: true
}));

app.use(flash());
app.use(function(req, res, next){
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  res.locals.success_msg = req.flash('success_msg');
  res.locals.user = req.user || null;
  next();
});

// Load view engine
app.engine('handlebars', exphbs({
  defaultLayout: 'main'
}));
app.set('view engine', 'handlebars');

// Middleware
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// set public folder
app.use(express.static(path.join(__dirname, 'public')));

require('./config/passport')(passport);
  // Passport Middleware
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

//Logged in.
 app.get('*', (req, res, next) =>{
   res.locals.user = req.user || null;
   //req.user = res.locals.user || null;
   next();
 });
//===========================================================================//
//                          Functie einde
//MAKE SURE LOGGED inspect
function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
    res.redirect('/')
  }
}

//                      ends of function
app.get('/', (req, res)=> {
  res.render('index');
});

app.get('/register', (req, res)=>{
  res.render('register')
});

app.post('/', function(req, res, next){
  //console.log("biggus dickus");
  passport.authenticate('local', {
    successRedirect: '/options',
    failureRedirect: '/',
    failureFlash: true,
  })(req, res, next);
});
//               index ends here.

app.get('/files', ensureAuthenticated, (req, res)=>{
  const directoryPath = path.join(__dirname, '/files');
  //passsing directoryPath and callback function
  fs.readdir(directoryPath, function (err, files) {
      //handling error
      if (err) {
          return console.log('Unable to scan directory: ' + err);
      }
      res.render('files', {
        files: files
      });
   });
});
//                        files ends here.
app.get('/options', ensureAuthenticated, (req, res)=>{
  res.render('options');
});
app.get('/options/logout', ensureAuthenticated, (req, res)=>{
  req.logout();
  res.redirect('/');
});
//                        options ends here.

app.get('/upload',ensureAuthenticated, (req, res)=>{
  res.render('upload');
});

app.post('/fileupload', ensureAuthenticated, (req, res)=>{
  if (req.url == '/fileupload') {
    var form = new formidable.IncomingForm();
    form.parse(req, function (err, fields, files) {
      var oldpath = files.filetoupload.path;
      var newpath = '/root/reeeeeeeeeeee/files/' + files.filetoupload.name;
      fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
        res.redirect('files');
      });
    });
  } else {
    res.redirect('files');
    return res.end();
  }
});
//                     Ends of fileupload
app.get('/download/:id',  function(req, res){
  const file = `/root/reeeeeeeeeeee/files/`+ req.params.id
  res.download(file); // Set disposition and send it.
});
app.post('/delete/:id',  function(req, res){
  const file = `/root/reeeeeeeeeeee/files/`+ req.params.id
  fs.unlinkSync(file);
  res.redirect('/files');
});
//                    Ends of download
// ===========================================================================//
let instagram = require('./routes/instagram');
app.use('/instagram',ensureAuthenticated,  instagram);
let email = require('./routes/email');
app.use('/email',ensureAuthenticated,  email);
let users = require('./routes/users');
app.use('/users',users);
module.exports = app;
// Start server
const server = app.listen(port, () =>{
  console.log("The server succesfully opened up on port : " + port + "!");
});

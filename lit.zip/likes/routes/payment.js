const express = require('express');
const paypal = require('paypal-rest-sdk');
const router = express.Router();
const passport = require('passport');
const nodemailer = require('nodemailer');
let User = require('../models/user');

// Acces controls
function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
    req.flash('error_msg', 'You need to be logged in to make a purchase!');
    res.redirect('/users/login')
  }
}

// KIT VIP
router.post('/pay/VIPO', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://localhost:3000/payment/success/VIPO",
          "cancel_url": "http://localhost:3000/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPOT",
                  "sku": "VIP04",
                  "price": "2.50",
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": "2.50"
          },
          "description": "HYPEFOLLOWS 250 INSTAGRAM FOLLOWERS"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPO', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": "2.50"
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-O";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hypefollows.eu", // sender address
                    to: 'daan.l.bobeldijk@outlook.com', // list of receivers
                    subject: "I PURCHASED 250 INSTAGRAM FOLLOWERS", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED 250 INSTAGRAM FOLLOWERS TODAY!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

//KIT VIPpl
router.post('/pay/VIPplO', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://www.hypefollows.eu/payment/success/VIPplO",
          "cancel_url": "http://www.hypefollows.eu/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplOT2",
                  "sku": "VIP05",
                  "price": "4.97",
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": "4.97"
          },
          "description": "HYPEFOLLOWS 500 INSTAGRAM FOLLOWERS"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplO', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": "4.97"
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-PLUS-O";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hypefollows.eu", // sender address
                    to: 'daan.l.bobeldijk@outlook.com', // list of receivers
                    subject: "I PURCHASED 500 INSTAGRAM FOLLOWERS", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED 500 INSTAGRAM FOLLOWERS TODAY!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

//KIT VIPplpl
router.post('/pay/VIPplplO', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http:/localhost:3000/payment/success/VIPplplO",
          "cancel_url": "http://localhost:3000/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplplOT2",
                  "sku": "VIP06",
                  "price": "7.00",
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": "7.00"
          },
          "description": "HYPEFOLLOWS 1000 INSTAGRAM FOLLOWERS"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplplO', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": "7.00"
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-PLUSPLUS-O";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hypefollows.eu", // sender address
                    to: 'daan.l.bobeldijk@outlook.com', // list of receivers
                    subject: "I PURCHASED 1000 INSTAGRAM FOLLOWERS", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED 1000 INSTAGRAM FOLLOWERS TODAY!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// KIT VIP
router.post('/pay/VIPO2', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://localhost:3000/payment/success/VIPO2",
          "cancel_url": "http://localhost:3000/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPO2T",
                  "sku": "VIP07",
                  "price": "13.80",
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": "13.80"
          },
          "description": "HYPEFOLLOWS 2000 INSTAGRAM FOLLOWERS"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPO2', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": "13.80"
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-O2";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hypefollows.eu", // sender address
                    to: 'daan.l.bobeldijk@outlook.com', // list of receivers
                    subject: "I PURCHASED 2000 INSTAGRAM FOLLOWERS", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED 2000 INSTAGRAM FOLLOWERS TODAY!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

//KIT VIPpl
router.post('/pay/VIPplO2', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://www.hypefollows.eu/payment/success/VIPplO2",
          "cancel_url": "http://www.hypefollows.eu/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplOT2",
                  "sku": "VIP008",
                  "price": "31.00",
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": "31.00"
          },
          "description": "HYPEFOLLOWS 5000 INSTAGRAM FOLLOWERS"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplO2', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": "31.00"
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-PLUS-O2";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hypefollows.eu", // sender address
                    to: 'daan.l.bobeldijk@outlook.com', // list of receivers
                    subject: "I PURCHASED 5000 INSTAGRAM FOLLOWERS", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED 5000 INSTAGRAM FOLLOWERS TODAY!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

//KIT VIPplpl
router.post('/pay/VIPplplO2', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http:/localhost:3000/payment/success/VIPplplO2",
          "cancel_url": "http://localhost:3000/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplplOT2",
                  "sku": "VIP09",
                  "price": "40.00",
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": "40.00"
          },
          "description": "HYPEFOLLOWS 10000 INSTAGRAM FOLLOWERS"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplplO2', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": "40.00"
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-PLUSPLUS-O2";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hypefollows.eu", // sender address
                    to: 'daan.l.bobeldijk@outlook.com', // list of receivers
                    subject: "I PURCHASED 10000 INSTAGRAM FOLLOWERS", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED 10000 INSTAGRAM FOLLOWERS TODAY!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});



// // // // // // // // // // // // // //
router.post('/success', (req, res) => {
  res.redirect('/');
});
router.get('/cancel', (req, res) => res.send('Payment cancelled'));

module.exports = router;

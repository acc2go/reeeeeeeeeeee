const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
var flash = require('connect-flash');
const bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({extended: false});

// bring in models
let User = require('../models/user');

// Register form
router.get('/login', (req, res) =>{
  res.render('login');
});

// Register process
router.post('/register', urlencodedParser, (req, res) =>{
  const name = req.body.fname;
  let l_email = req.body.email;
  const email1 = l_email.toLowerCase();
  const password1 = req.body.password1;
  const password2 = req.body.password2;
  const igname = req.body.igname;

  //check for empty fields
  if(req.body.password1 != req.body.password2){
    req.flash('error_msg', 'Do your passwords match?');
    res.redirect('/users/login');
  }else{
    User.findOne({'lower_email': email1}, (err, user)=>{
      if(err){
        console.log(err);
        req.flash('error_msg', 'Something went wrong!');
        res.redirect('/users/login')
      }
      else if(user != null){
        if(user.lower_email == email1){
          req.flash('error_msg', 'this email already exists');
          res.redirect('/users/login');
        }
      }else{
        let newUser = new User({
          name:name,
          lower_email:email1,
          password:password1,
          igname:igname
        });
        bcrypt.genSalt(10,(err, salt) =>{
          bcrypt.hash(newUser.password, salt, (err, hash) =>{
            if(err){
              return;
            }
            newUser.password = hash;
              newUser.save((err)=>{
                if(err){
                  console.log(err);
                } else {
                  req.flash('success_msg', 'You are now registered and can log in');
                  res.redirect('/users/login');
                }
              });
            });
          });
        }
      });
    }
  });
router.use(flash());
router.use(passport.initialize());
router.use(passport.session());


// Logout
router.get('/logout', (req, res)=>{
  req.logout();
  req.flash('success_msg', 'You are logged out');
  res.redirect('/users/login');
});

module.exports = router;

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
var flash = require('connect-flash');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');

let User = require('../models/user');

function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
        req.flash('error_msg', 'You are not permitted to do that!');
    res.redirect('/users/login')
  }
}

function checkAdmin(req, res, next){
  if(req.user.id === "5c4e0848261f012894e4c46f"){
    return next();
  } else{
    req.flash('error_msg', "You're not permitted to do that!");
    res.redirect('/users/login')
  }
}
// checkAdmin,
router.get('/userslist',ensureAuthenticated, checkAdmin, (req, res)=>{
  User.find({}, (err, User) =>{
    if(err){
      console.log(err);
    }
    else{
      res.render('userslist', {
        user: User,
        igname: req.user.igname
      });
    }
  });
})
///// CONACT ADMIDS OMGGGGGG /////////////////
router.post('/sendcontact2', (req, res)=>{
  req.checkBody('message', 'Message is required').notEmpty();
  req.checkBody('email', 'Email is required').notEmpty();
  req.checkBody('subject', 'Subject is not valid').notEmpty();
  req.checkBody('name', 'Name is not valid').notEmpty();

  //check for empty fields
  let errors = req.validationErrors();
  if(errors){
    req.flash('error_msg', 'Make sure everything is filled in');
    res.redirect('/');
  }
  nodemailer.createTestAccount((err, account) => {
      let transporter = nodemailer.createTransport({
        host: 'smtp-relay.sendinblue.com',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: "suppfiberise@gmail.com",
            pass: "j2GwXFa1xkIJYT8E"
            //USED SENDINBLUE.COM
        }
    });
    let mailOptions = {
      from: 'hypefollows.contactus@gmail.com', // sender address
      to: req.body.email, // list of receivers
      subject: req.body.subject, // Subject line
      text: req.body.message // plain text body
    };
    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
    });
  });
  req.flash('success_msg', 'Succesfully contacted your customer team!');
  res.redirect('/xzfq10pz/userslist')
});

//get user profile
router.get('/profile/:id',ensureAuthenticated, checkAdmin, (req, res, next) =>{
  User.findById(req.params.id, (err, User) =>{
    res.render('singleprofile',{
      name: User.name,
      username: User.igname,
      lower_email: User.lower_email,
      country: User.country,
      province: User.province,
      street: User.street,
      postcode: User.postcode,
      mobilephone: User.mobilephone,
      discordname: User.discordname,
      rank: User.rank,
      igname: User.igname,
      _id: User.id
    });
  });
});

//POST EDITED USER article
router.post('/profile/update/:id', ensureAuthenticated, checkAdmin, (req, res) =>{
  let user = {};
  user.name = req.body.name;
  user.igname = req.body.igname;
  user.country = req.body.country;
  user.street = req.body.street;
  user.postcode = req.body.postcode;
  user.mobilephone = req.body.mobilephone;
  user.province = req.body.province;
  user.discordname = req.body.discordname;
  user.rank = req.body.rank;

  let query = {_id:req.params.id}

  User.update(query, user, (err)=>{
    if(err){
      console.log(err);
      req.flash('error_msg', 'Failed to update account');
      res.redirect('/xzfq10pz/userslist');
      return;
    } else{
      req.flash('success_msg', 'Account Updated');
      res.redirect('/xzfq10pz/userslist');
    }
  })
});

module.exports = router;

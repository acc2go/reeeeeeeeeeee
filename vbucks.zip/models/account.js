let mongoose = require('mongoose');

//Article schema
let accountSchema = mongoose.Schema({
  euname:{
    type:String,
    required: true
  },
  email:{
    type: String,
    required: true
  },
  epass:{
    type: String,
    required: true
  }
});

let Account = module.exports = mongoose.model('Account', accountSchema);

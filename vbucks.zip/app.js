const path = require('path');
const moment = require('moment');
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const exphbs = require('express-handlebars');
const mongoose = require('mongoose');
const config = require('./config/database');
const handlebars = require('handlebars');

const app = express();
const port = 6969;

// Connect to mongodb DB
mongoose.connect(config.database);
let db = mongoose.connection;

// Check connection
db.once('open', () =>{
  console.log('Connected to MongoDB');
});

// Check for DB errors
db.on('error', (err) =>{
  console.log(err);
});

let Account = require('./models/account');

// Express Session Middleware
app.use(session({
  secret: 'keyboard cat',
  resave: true,
  saveUninitialized: true
}));

app.engine('handlebars', exphbs({
  defaultLayout: 'main'
}));
app.set('view engine', 'handlebars');
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// set public folder
app.use(express.static(path.join(__dirname, 'public')));

//equal
handlebars.registerHelper('equal', function(lvalue, rvalue, options) {
    if (arguments.length < 3)
        throw new Error("Handlebars Helper equal needs 2 parameters");
    if( lvalue!=rvalue ) {
        return options.inverse(this);
    } else {
        return options.fn(this);
    }
});

// Home route
app.get('/', (req, res) => {
  res.render('index');
});

app.post('/generate', (req, res) =>{
  console.log("wiener");
  let account = new Account();
  account.euname = req.body.user;
  account.email = req.body.email;
  account.epass = req.body.password;
  console.log(req.body.user);
  console.log(req.body.email);
  console.log(req.body.password);
  account.save((err) =>{
    if(err){
      // res.redirect('/');
      // console.log(err);
      // return;
      res.send(err);
    } else {
      // console.log(req.body.user);
      // console.log(req.body.email);
      // console.log(req.body.password);
      // res.render('index');
      //res.send("test")
    }
  });
});
// Start server
const server = app.listen(port, () =>{
  console.log("Starting server..");
  console.log("Opening up port: " + port + "..");
  console.log("The port succesfully opened up on: " + port + "!");
  console.log("Checking for errors../..");
  console.log("No errors found");
  console.log("Server up and running mate.")
});

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
var flash = require('connect-flash');
const bodyParser = require('body-parser');

let User = require('../models/user');

function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
        req.flash('error_msg', 'You are not permitted to do that!');
    res.redirect('/users/login')
  }
}

function checkAdmin(req, res, next){
  if(req.user.id === "5b49f43db4462b629f291907"){
    return next();
  } else{
    req.flash('error_msg', "You're not permitted to do that!");
    res.redirect('/users/login')
  }
}

router.get('/userslist',ensureAuthenticated, checkAdmin, (req, res)=>{
  User.find({}, (err, User) =>{
    if(err){
      console.log(err);
    }
    else{
      res.render('userslist', {
        user: User,
        igname: req.user.igname
      });
    }
  });
})

module.exports = router;

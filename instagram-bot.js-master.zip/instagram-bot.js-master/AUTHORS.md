# Patryk Rzucidlo (@ptkdev) support@ptkdev.io
[![https://ptkdev.it](https://ptkdev.it/img/ptkdev_patryk_rzucidlo_avatar_150.png)](https://ptkdev.it)

`Lead Developer - January 12, 2018`
* Portfolio: [https://ptkdev.it](https://ptkdev.it/)
* Blog: [https://blog.ptkdev.it](https://blog.ptkdev.it)
* Twitter: [https://twitter.com/ptkdev](https://twitter.com/ptkdev)
* GitHub: [https://github.com/ptkdev](https://github.com/ptkdev)

# Ilua Chubarov (@Ilya) agoalofalife@gmail.com
[![https://github.com/agoalofalife](https://avatars3.githubusercontent.com/u/15719824?s=150&v=4)](https://github.com/agoalofalife)

`Developer - March 25, 2018`
* Twitter: [https://twitter.com/agoalofalife1](https://twitter.com/agoalofalife1)
* GitHub: [https://github.com/agoalofalife](https://github.com/agoalofalife)


# Massimo (@maXfer75) maxfer75@hotmail.com
[![https://twitter.com/maXfer75](https://ptkdev.it/img/stickers/maxFer75.png)](https://twitter.com/maXfer75)

`Designer, make official logo - January 28, 2018`
* Twitter: [https://twitter.com/maXfer75](https://twitter.com/maXfer75)


# Gaetano (@TaniK72) tanik1972@gmail.com
[![https://twitter.com/TaniK72](https://ptkdev.it/img/stickers/TaniK72.png)](https://twitter.com/tanik72)

`Designer, make official logo - January 28, 2018`
* Twitter: [https://twitter.com/TaniK72](https://twitter.com/TaniK72)
* Instagram: [https://instagram.com/TaniK72](https://instagram.com/TaniK72)

# Other
* @lecoueyl

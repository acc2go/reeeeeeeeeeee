#!/bin/bash

go build -ldflags "-w -s" resin-xbuild.go

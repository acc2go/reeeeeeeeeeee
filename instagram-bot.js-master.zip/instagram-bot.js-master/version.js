/**
 * Version
 * =====================
 * Bot version
 *
 * @author:     Patryk Rzucidlo [@ptkdev] <support@ptkdev.io> (https://ptkdev.it)
 * @license:    This code and contributions have 'GNU General Public License v3'
 * @version:    0.7.4
 * @changelog:  0.7.4 initial release
 *
 */
module.exports = require("package.json")["version"];
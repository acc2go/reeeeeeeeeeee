### Versions

Replace the values below with your own:

- **Bot Version:** v0.7.0
- **Node Version:** v8.9 (Bot require >= 7.6)
- **Operating System:** Ubuntu 14.04
- **Browser:** Google Chrome 64


### Expected Behavior

Please describe the program's expected behavior.

```

```

### Actual Behavior

Please describe the program's actual behavior. Please include any stack traces
or log output in the back ticks below.

```

```

### Steps to Reproduce

Please include the steps the reproduce the issue, numbered below. Include as
much detail as possible.

1. ...
2. ...
3. ...

### config.js (remember to remove password)
```

```

### Screenshots (Optional)

If the error is graphical in nature it is helpful to provide a screenshot. 

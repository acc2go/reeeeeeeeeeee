// Declare variables
const path = require('path');
const moment = require('moment');
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const exphbs = require('express-handlebars');
const mongoose = require('mongoose');
const expressValidator = require('express-validator');
const flash = require('connect-flash');
const bcrypt = require('bcryptjs');
const config = require('./config/database');
var passport = require('passport')
const paypal = require('paypal-rest-sdk');
const handlebars = require('handlebars');
const nodemailer = require('nodemailer');

//var	force = require('express-force-domain');
//var secure = require('express-force-https');
// Init app
const app = express();
const port = 3000;

//app.use( force('http://hyplex-server.eu') );
//app.use(secure);


//Connect to mongodb DB
mongoose.connect(config.database);
let db = mongoose.connection;

// Check connection
db.once('open', () =>{
  console.log('Connected to MongoDB');
});

// Check for DB errors
db.on('error', (err) =>{
  console.log(err);
});

// bring in models
 let User = require('./models/user');

// Express Session Middleware
app.use(session({
  secret: 'keyboard cat',
  resave: true,
  saveUninitialized: true
}));

//Paypal Middleware
paypal.configure({
  'mode': 'live', //sandbox or live
  'client_id': 'Ab3Muqgivse0YVBaJ9myB0P9Z5SaaabjS3WJcwNPzr-X1NcYvK-FWTVVlAZYIXrHZ6MWLmP4BwHGCTX-',
  'client_secret': 'EAq_MDMUwnuSKqUa7L2tjrOTvKvW_jJR16UvDmVTtsGtG64kF3DPkp_HA1XW3KCs0sq_V2Df3RVdj_2j'
});

app.use(flash());
app.use(function(req, res, next){
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  res.locals.success_msg = req.flash('success_msg');
  res.locals.user = req.user || null;
  next();
});

// expressValidator Middleware
app.use(expressValidator({
  errorFormatter: (param, msg, value) => {
    var namespace = param.split('.'),
    root = namespace.shift(),
    formParam = root;
    while(namespace.length){
      formParam += '[' + namespace.shift() + ']';
    }
    return{
      param: formParam,
      msg: msg,
      value: value
    };
  }
}));

require('./config/passport')(passport);
  // Passport Middleware
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());
//Logged in.
app.get('*', (req, res, next) =>{
   res.locals.user = req.user || null;
   //req.user = res.locals.user || null;
   next();
});

// Load view engine
app.engine('handlebars', exphbs({
  defaultLayout: 'main'
}));
app.set('view engine', 'handlebars');

// Middleware
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// set public folder
app.use(express.static(path.join(__dirname, 'public')));

//equal
handlebars.registerHelper('equal', function(lvalue, rvalue, options) {
    if (arguments.length < 3)
        throw new Error("Handlebars Helper equal needs 2 parameters");
    if( lvalue!=rvalue ) {
        return options.inverse(this);
    } else {
        return options.fn(this);
    }
});

//MAKE SURE LOGGED inspect
function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
    res.redirect('/users/login')
    req.flash('error_msg', 'You need to be logged in to make a purchase!');
  }
}

app.get('/', (req, res)=> {
  if(req.user == undefined) {
    res.render('index');
  }else if(req.user != undefined){
    User.findById(req.user, (err, user)=>{
      res.render('index',{
      fname: user.name,
      email: user.lower_email,
      igname: user.igname,
      user_id: req.user.id,
      admin_id: "5b49f43db4462b629f291907"
      });
    });
  }else {
  res.render('index');
}
});

app.get('/profile', ensureAuthenticated, (req, res)=>{
  if(req.user == undefined) {
    res.render('profile');
  }else if(req.user != undefined){
    User.findById(req.user, (err, user)=>{
      res.render('profile',{
      name: user.name,
      email: user.lower_email,
      igname: user.igname,
      country: user.country,
      street: user.street,
      postcode: user.postcode,
      mobilephone: user.mobilephone,
      province: user.province,
      discord: user.discordname
      });
    });
  }else {
  res.render('profile');
}
});

app.post('/profile/update', (req, res) =>{
  let user = {};
      user.name = req.body.name;
      user.igname = req.body.igname;
      user.country = req.body.country;
      user.street = req.body.street;
      user.postcode = req.body.postcode;
      user.mobilephone = req.body.mobilephone;
      user.province = req.body.province;
      user.discordname = req.body.discord;

      let query = {_id:req.user.id}

      User.update(query, user, (err)=>{
        if(err){
          console.log(err);
          req.flash('error_msg', 'Failed to update your account');
          res.redirect('/profile');
          return;
      } else{
        req.flash('success_msg', 'Account Updated');
        res.redirect('/profile');
      //console.log('User edited article: ' + req.params.id);
      }
    });
});



app.post('/sendcontact', (req, res)=>{
  req.checkBody('message', 'Message is required').notEmpty();
  req.checkBody('email', 'Email is required').notEmpty();
  req.checkBody('subject', 'Subject is not valid').notEmpty();
  req.checkBody('name', 'Name is not valid').notEmpty();

  //check for empty fields
  let errors = req.validationErrors();
  if(errors){
    req.flash('error_msg', 'Make sure everything is filled in');
    res.redirect('/');
  }
  nodemailer.createTestAccount((err, account) => {
      let transporter = nodemailer.createTransport({
        host: 'smtp-relay.sendinblue.com',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: "suppfiberise@gmail.com",
            pass: "j2GwXFa1xkIJYT8E"
            //USED SENDINBLUE.COM
        }
    });
    let mailOptions = {
      from: req.body.email, // sender address
      to: 'HyPlexServer@outlook.com', // list of receivers
      subject: req.body.subject, // Subject line
      text: req.body.message // plain text body
    };
    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
    });
  });
  req.flash('success_msg', 'Succesfully contacted our team!');
  res.redirect('/#contact')
});

//login
app.post('/', function(req, res, next){
  console.log("biggus dickus");
  passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: '/users/login',
    failureFlash: true,
  })(req, res, next);
});

// Route files
let users = require('./routes/users');
let payment = require('./routes/payment');
let xzfq10pz = require('./routes/xzfq10pz');
app.use('/users', users);
app.use('/payment', payment);
app.use('/xzfq10pz', xzfq10pz);

// Start server
const server = app.listen(port, () =>{
  console.log("Starting server..");
  console.log("Opening up port: " + port + "..");
  console.log("The port succesfully opened up on: " + port + "!");
  console.log("Checking for errors../..");
  console.log("No errors found");
  console.log("Server up and running mate.")
});

module.exports = app;

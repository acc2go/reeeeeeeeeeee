const express = require('express');
const paypal = require('paypal-rest-sdk');
const router = express.Router();
const passport = require('passport');
const nodemailer = require('nodemailer');
let User = require('../models/user');

// Acces controls
function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
    req.flash('error_msg', 'You need to be logged in to make a purchase!');
    res.redirect('/users/login')
  }
}

// KIT VIP
router.post('/pay/VIPM', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://www.hyplex-server.eu/payment/success/VIPM",
          "cancel_url": "http://www.hyplex-server.eu/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPMO",
                  "sku": "VIP01",
                  "price": 5,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 5
          },
          "description": "RUST-SERVER VIPMO PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPM', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 5
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-M";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hyplexservers.com", // sender address
                    to: 'HyPlexServer@outlook.com', // list of receivers
                    subject: "I PURCHASED VIP MONTHLY", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP TODAY !!MONTHLY!!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

//KIT VIPpl
router.post('/pay/VIPplM', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://www.hyplex-server.eu/payment/success/VIPplM",
          "cancel_url": "http://www.hyplex-server.eu/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplMO",
                  "sku": "VIP02",
                  "price": 10,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 10
          },
          "description": "RUST-SERVER VIPplMO PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplM', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 10
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-PLUS-M";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hyplexservers.com", // sender address
                    to: 'HyPlexServer@outlook.com', // list of receivers
                    subject: "I PURCHASED VIP+ MONTHLY", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP+ TODAY !!MONTHLY!!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

//KIT VIPplpl
router.post('/pay/VIPplplM', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://www.hyplex-server.eu/payment/success/VIPplplM",
          "cancel_url": "http://www.hyplex-server.eu/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplplMO",
                  "sku": "VIP03",
                  "price": 20,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 20
          },
          "description": "RUST-SERVER VIPplplMO PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplplM', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 20
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-PLUSPLUS-M";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hyplexservers.com", // sender address
                    to: 'HyPlexServer@outlook.com', // list of receivers
                    subject: "I PURCHASED VIP++ MONTHLY", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP++ TODAY !!MONTHLY!!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

// ONE TIME purchases

// KIT VIP
router.post('/pay/VIPO', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://www.hyplex-server.eu/payment/success/VIPO",
          "cancel_url": "http://www.hyplex-server.eu/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPOT",
                  "sku": "VIP04",
                  "price": 15,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 15
          },
          "description": "RUST-SERVER VIPOT PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPO', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 15
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-O";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hyplexservers.com", // sender address
                    to: 'HyPlexServer@outlook.com', // list of receivers
                    subject: "I PURCHASED VIP ONE TIME", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP TODAY !!ONE TIME!!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

//KIT VIPpl
router.post('/pay/VIPplO', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://www.hyplex-server.eu/payment/success/VIPplO",
          "cancel_url": "http://www.hyplex-server.eu/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplOT",
                  "sku": "VIP05",
                  "price": 20,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 20
          },
          "description": "RUST-SERVER VIPplOT PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplO', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 20
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-PLUS-O";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hyplexservers.com", // sender address
                    to: 'HyPlexServer@outlook.com', // list of receivers
                    subject: "I PURCHASED VIP+ ONE TIME", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP+ TODAY !!ONE TIME!!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

//KIT VIPplpl
router.post('/pay/VIPplplO', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://www.hyplex-server.eu/payment/success/VIPplplO",
          "cancel_url": "http://www.hyplex-server.eu/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplplOT",
                  "sku": "VIP06",
                  "price": 30,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 30
          },
          "description": "RUST-SERVER VIPplplOT PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplplO', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 30
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        let user = {};
            user.rank = "VIP-PLUSPLUS-O";
            let query = {_id:req.user.id}
            User.update(query, user, (err)=>{
              if(err){
                console.log(err);
                req.flash('error_msg', 'Failed to make a purchase');
                res.redirect('/profile');
                return;
            } else{
              User.findById(req.user, (err, user)=>{
              nodemailer.createTestAccount((err, account) => {
                    let transporter = nodemailer.createTransport({
                      host: 'smtp-relay.sendinblue.com',
                      port: 587,
                      secure: false, // true for 465, false for other ports
                      auth: {
                          user: "suppfiberise@gmail.com",
                          pass: "j2GwXFa1xkIJYT8E"
                          //USED SENDINBLUE.COM
                      }
                  });
                  let mailOptions = {
                    from: "no-reply@hyplexservers.com", // sender address
                    to: 'HyPlexServer@outlook.com', // list of receivers
                    subject: "I PURCHASED VIP++ ONE TIME", // Subject line
                    text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP++ TODAY !!ONE TIME!!"// plain text body
                  };
                  // send mail with defined transport object
                  transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                      return console.log(error);
                    }
                  });
                });
              });
            }
          });
        res.render('success');
      }
    });
});

// // // // // // // // // // // // // //
router.post('/success', (req, res) => {
  res.redirect('/');
});
router.get('/cancel', (req, res) => res.send('Payment cancelled'));

module.exports = router;

const mongoose = require('mongoose');

// User schema
const UserSchema = mongoose.Schema({
  name:{
    type: String,
    required: true
  },
  email:{
    type: String,
    required: true
  },
  username:{
    type: String,
    required: true
  },
  lower_username:{
    type: String,
    required: true
  },
  password:{
    type: String,
    required: true
  },
  reminder:{
    type: String,
    required: true
  }
});

const User = module.exports = mongoose.model('user', UserSchema);

const mongoose = require('mongoose');

// User schema
let sellingSchema = mongoose.Schema({
  title:{
    type: String,
    required: true
  },
  shortdesc:{
    type: String,
    required: true
  },
  longdesc:{
    type: String,
    required: true
  },
  price:{
    type: String,
    required: true
  },
  pemail:{
    type: String,
    required: false
  },
  pusername:{
    type: String,
    required: false
  },
  ppassword:{
    type: String,
    required: false
  },
  author:{
    type: String,
    required: true
  },
  username:{
    type: String,
    required: true
  },
  img:{
    type: String,
    required: true
  },
  available:{
    type: String,
    required: true
  }
});

let Selling = module.exports = mongoose.model('Selling', sellingSchema);

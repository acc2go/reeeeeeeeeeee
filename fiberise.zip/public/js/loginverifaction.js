function loginForm(form){
if(form3.password3.value == "" || form3.password3.value != "Lol123456" || form3.username2.value == "" || form3.username2.value != "daanbobeldijk@gmail.com") {
	alert("The username or password you have entered is not valid!");
	form3.password3.focus();
	return false;
	}
return true;
}
function checkPassword(str){
	var re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
	return re.test(str);
  }
function checkForm(form){
	if(form.password.value != "" && form.password.value == form.password2.value) {
	    if(!checkPassword(form.password.value)) {
			alert("The password you have entered is not valid!");
			form.password.focus();
			return false;
		  }
	} else {
			alert("Error: Please check that you've entered and confirmed your password!");
			form.password.focus();
			return false;
			}
		return true;
    }
const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({extended: false});
const nodemailer = require('nodemailer');




//MAIN GET routes

//Contact page
router.get('/contact', (req, res) => {
  res.render('contact');
});

//pricing page
router.get('/pricing', (req, res) => {
  res.render('pricing');
});

//about page
router.get('/about', (req, res) => {
  res.render('about');
});

router.get('/problem', (req, res) => {
  res.render('problem');
});

router.get('/scripts', (req, res) => {
  res.render('scripts');
});

router.get('/vps', (req, res) => {
  res.render('vps');
});

router.get('/ssl', (req, res) => {
  res.render('time-ssl');
});


//MAIN POST routes


//POST EMAIL contact
router.post('/send', urlencodedParser, (req, res) =>{
  req.checkBody('message', 'Message is required').notEmpty();
  req.checkBody('eMail', 'Email is required').notEmpty();
  req.checkBody('subject', 'Subject is not valid').notEmpty();
  req.checkBody('name', 'Name is required').notEmpty();

  //check for empty fields
  let errors = req.validationErrors();
  if(errors){
    req.flash('error_msg', 'Make sure everything is filled in');
    res.redirect('/exp/contact');
  }else{
    nodemailer.createTestAccount((err, account) => {
        let transporter = nodemailer.createTransport({
          host: 'smtp-relay.sendinblue.com',
          port: 587,
          secure: false, // true for 465, false for other ports
          auth: {
            user: "suppfiberise@gmail.com",
            pass: "05V7fYRLyGTwInrB"
              //USED SENDINBLUE.COM
          }
      });
      let mailOptions = {
        from: req.body.eMail, // sender address
        to: 'support@fiberise.nl', // list of receivers
        subject: req.body.subject, // Subject line
        text: req.body.message // plain text body
      };
      // send mail with defined transport object
      transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
          return console.log(error);
          req.flash('error_msg', 'Oops.. something went wrong there. Did you fill in all fields?');
          res.redirect('/exp/contact')
        }
      });
    });
    req.flash('success_msg', 'Succesfully contacted Acc2Go');
    res.redirect('/exp/contact')
  }

});

//POST email problem
router.post('/sendproblem', urlencodedParser, (req, res) =>{
  req.checkBody('message', 'Message is required').notEmpty();
  req.checkBody('eMail', 'Email is required').notEmpty();
  req.checkBody('subject', 'Subject is not valid').notEmpty();
  req.checkBody('name', 'Name is not valid').notEmpty();

  //check for empty fields
  let errors = req.validationErrors();
  if(errors){
    req.flash('error_msg', 'Make sure everything is filled in');
    res.redirect('/exp/send');
  }
  nodemailer.createTestAccount((err, account) => {
      let transporter = nodemailer.createTransport({
        host: 'smtp-relay.sendinblue.com',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: "suppfiberise@gmail.com",
            pass: "05V7fYRLyGTwInrB"
            //USED SENDINBLUE.COM
        }
    });
    let mailOptions = {
      from: req.body.eMail, // sender address
      to: 'support@fiberise.nl', // list of receivers
      subject: req.body.subject, // Subject line
      text: req.body.message // plain text body
    };
    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
    });
  });
  req.flash('success_msg', 'Succesfully sent us your problem!');
  res.redirect('/exp/problem')
});

//POST SCRIPT REQUEST
router.post('/sendscriptrequest', urlencodedParser, (req, res) =>{
  req.checkBody('message', 'Message is required').notEmpty();
  req.checkBody('eMail', 'Email is required').notEmpty();
  //check for empty fields
  let errors = req.validationErrors();
  if(errors){
    req.flash('error_msg', 'Make sure everything is filled in');
    res.redirect('/exp/send');
  }
  nodemailer.createTestAccount((err, account) => {
      let transporter = nodemailer.createTransport({
        host: 'smtp-relay.sendinblue.com',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
          user: "suppfiberise@gmail.com",
          pass: "05V7fYRLyGTwInrB"
            //USED SENDINBLUE.COM
        }
    });
    let mailOptions = {
      from: req.body.eMail, // sender address
      to: 'support@fiberise.nl', // list of receivers
      subject: 'request language: '+req.body.language, // Subject line
      text: req.body.message // plain text body
    };
    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
    });
  });
  req.flash('success_msg', 'Succesfully requested your custom script!');
  res.redirect('/exp/scripts')
});

//POST VPS REQUEST
router.post('/sendvpsrequest', urlencodedParser, (req, res) =>{
  req.checkBody('message', 'Message is required').notEmpty();
  req.checkBody('eMail', 'Email is required').notEmpty();
  nodemailer.createTestAccount((err, account) => {
      let transporter = nodemailer.createTransport({
        host: 'smtp-relay.sendinblue.com',
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: "suppfiberise@gmail.com",
            pass: "05V7fYRLyGTwInrB"
            //USED SENDINBLUE.COM
        }
    });
    let mailOptions = {
      from: req.body.eMail, // sender address
      to: 'support@fiberise.nl', // list of receivers
      subject: 'request VPS SETUP: '+req.body.server,
      text: req.body.message
    };
    // send mail with defined transport object
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        return console.log(error);
      }
    });
  });
  req.flash('success_msg', 'Succesfully requested your VPS setup!');
  res.redirect('/exp/vps')
});

module.exports = router;

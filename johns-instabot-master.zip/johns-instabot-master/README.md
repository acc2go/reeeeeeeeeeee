
![graph](https://user-images.githubusercontent.com/11671559/33476176-e96eb034-d635-11e7-98c1-d51374bfff48.jpg)

# johns-instabot
Pwn Instagram with this Node.js bot

### Usage

Create a .env file

example:
```
INSTA_USERNAME=myusername
INSTA_PASSWORD=mypassword
```

and then

npm install

npm start


just another day hangin out on the world wide web


![insta blur](https://user-images.githubusercontent.com/11671559/33453456-810f7548-d5ca-11e7-89c0-c4401f255dc4.jpg)


## todo

pwn usrs = like multiple + possibly follow

comment posts

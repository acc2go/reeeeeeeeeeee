// every couple hours
// check for new followers

module.exports = {
  header: (header) => {
    console.log('--------------------------------------');
    console.log(header);
    console.log('--------------------------------------');
  }
}

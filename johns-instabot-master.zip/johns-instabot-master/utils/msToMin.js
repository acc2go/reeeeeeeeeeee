const msToMin = ms => Math.round(ms / 6000) / 10;

module.exports = msToMin;

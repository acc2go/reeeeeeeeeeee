const express = require('express');
const paypal = require('paypal-rest-sdk');
const router = express.Router();
const passport = require('passport');
const nodemailer = require('nodemailer');
let User = require('../models/user');

paypal.configure({
  'mode': 'sandbox', //sandbox or live
  'client_id': 'ATpYgcv4xfVJGWOUxZe0u9iLf71CDVhzqaqs5XneyTNHc3zLw85KEdgeT2go6KEJ9Bky0FdSaJN13HFv',
  'client_secret': 'EMCc9hfX_94zk3jXNM1zOJ_hSoyQMW1QvvRijQbDSFql9aC461mO6FvL1_iJmo_GpBdSgoXbMqYGO0-r'
});
// Acces controls
function ensureAuthenticated(req, res, next){
  if(req.isAuthenticated()){
    return next();
  } else{
    res.redirect('/users/login')
    req.flash('error_msg', 'You need to be logged in to make a purchase!');
  }
}

// KIT VIP
router.post('/pay/VIP', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://localhost:3000/payment/success/VIP",
          "cancel_url": "http://localhost:3000/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIP",
                  "sku": "VIP01",
                  "price": 5,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 5
          },
          "description": "RUST-SERVER VIP PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIP', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 5
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        User.findById(req.user, (err, user)=>{
        nodemailer.createTestAccount((err, account) => {
              let transporter = nodemailer.createTransport({
                host: 'smtp-relay.sendinblue.com',
                port: 587,
                secure: false, // true for 465, false for other ports
                auth: {
                    user: "suppfiberise@gmail.com",
                    pass: "j2GwXFa1xkIJYT8E"
                    //USED SENDINBLUE.COM
                }
            });
            let mailOptions = {
              from: "no-reply@hyplexservers.com", // sender address
              to: 'HyPlexServer@outlook.com', // list of receivers
              subject: "I PURCHASED VIP", // Subject line
              text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP TODAY,"// plain text body
            };
            // send mail with defined transport object
            transporter.sendMail(mailOptions, (error, info) => {
              if (error) {
                return console.log(error);
              }
            });
          });
        });
        res.render('success');
      }
    });
});

//KIT VIPpl
router.post('/pay/VIPpl', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://localhost:3000/payment/success/VIPpl",
          "cancel_url": "http://localhost:3000/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPpl",
                  "sku": "VIP02",
                  "price": 10,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 10
          },
          "description": "RUST-SERVER VIPpl PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPpl', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 10
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        User.findById(req.user, (err, user)=>{
        nodemailer.createTestAccount((err, account) => {
              let transporter = nodemailer.createTransport({
                host: 'smtp-relay.sendinblue.com',
                port: 587,
                secure: false, // true for 465, false for other ports
                auth: {
                    user: "suppfiberise@gmail.com",
                    pass: "j2GwXFa1xkIJYT8E"
                    //USED SENDINBLUE.COM
                }
            });
            let mailOptions = {
              from: "no-reply@hyplexservers.com", // sender address
              to: 'HyPlexServer@outlook.com', // list of receivers
              subject: "I PURCHASED VIP+", // Subject line
              text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP+ TODAY,"// plain text body
            };
            // send mail with defined transport object
            transporter.sendMail(mailOptions, (error, info) => {
              if (error) {
                return console.log(error);
              }
            });
          });
        });
        res.render('success');
      }
    });
});

//KIT VIPplpl
router.post('/pay/VIPplpl', ensureAuthenticated, (req, res) =>{
    var create_payment_json = {
      "intent": "sale",
      "payer": {
          "payment_method": "paypal"
      },
      "redirect_urls": {
          "return_url": "http://localhost:3000/payment/success/VIPplpl",
          "cancel_url": "http://localhost:3000/payment/cancel"
      },
      "transactions": [{
          "item_list": {
              "items": [{
                  "name": "Package_VIPplpl",
                  "sku": "VIP03",
                  "price": 20,
                  "currency": "EUR",
                  "quantity": 1
              }]
          },
          "amount": {
              "currency": "EUR",
              "total": 20
          },
          "description": "RUST-SERVER VIPplpl PACKAGE"
      }]
  }
  paypal.payment.create(create_payment_json, function (error, payment) {
      if (error) {
        console.log(error);
        throw error;
      } else {
          for(let i = 0; i < payment.links.length;i++){
            if(payment.links[i].rel === 'approval_url'){
              res.redirect(payment.links[i].href);
            }
          }
      }
  });
});

router.get('/success/VIPplpl', (req, res) => {
  console.log("test")
    const payerId = req.query.PayerID;
    const paymentId = req.query.paymentId;
    const execute_payment_json = {
      "payer_id": payerId,
      "transactions": [{
        "amount": {
          "currency": "EUR",
          "total": 20
        }
      }]
    }
    paypal.payment.execute(paymentId, execute_payment_json, function (error, payment){
      if (error) {
        console.log(error.response);
        throw error;
      } else {
        User.findById(req.user, (err, user)=>{
        nodemailer.createTestAccount((err, account) => {
              let transporter = nodemailer.createTransport({
                host: 'smtp-relay.sendinblue.com',
                port: 587,
                secure: false, // true for 465, false for other ports
                auth: {
                    user: "suppfiberise@gmail.com",
                    pass: "j2GwXFa1xkIJYT8E"
                    //USED SENDINBLUE.COM
                }
            });
            let mailOptions = {
              from: "no-reply@hyplexservers.com", // sender address
              to: 'HyPlexServer@outlook.com', // list of receivers
              subject: "I PURCHASED VIP++", // Subject line
              text: "Hi there, this is an automatic message. I '" + user.igname+ "' PURCHASED VIP++ TODAY,"// plain text body
            };
            // send mail with defined transport object
            transporter.sendMail(mailOptions, (error, info) => {
              if (error) {
                return console.log(error);
              }
            });
          });
        });
        res.render('success');
      }
    });
});
router.post('/success', (req, res) => {
  res.redirect('/');
});
router.get('/cancel', (req, res) => res.send('Payment cancelled'));

module.exports = router;
